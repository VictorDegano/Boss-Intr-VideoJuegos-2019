Pixel Dungeon
=============

Traditional roguelike game with pixel-art graphics and simple interface.

Pixel Dungeon on GooglePlay: 
https://play.google.com/store/apps/details?id=com.watabou.pixeldungeon

Official web-site: 
http://pixeldungeon.watabou.ru/

Developer's blog: 
http://pixeldungeon.tumblr.com/

To build the game you will need my unnamed game library:
https://github.com/watabou/PD-classes

DOWNLOADED FROM https://github.com/watabou/pixel-dungeon